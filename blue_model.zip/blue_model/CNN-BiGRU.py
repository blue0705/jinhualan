import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from keras.src.callbacks import EarlyStopping, Callback
from keras.src.layers import Dropout, BatchNormalization, MaxPooling2D, MaxPooling1D, AveragePooling1D
from keras.src.regularizers import L1L2, regularizers
from keras_self_attention import SeqSelfAttention
from sklearn.compose import ColumnTransformer
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from sklearn.preprocessing import MinMaxScaler, StandardScaler, OneHotEncoder, LabelEncoder
from sklearn.model_selection import train_test_split
from keras.models import Sequential
from keras.layers import Conv1D, GlobalAveragePooling1D, Bidirectional, GRU, Dense
from keras.optimizers import Adam
from imblearn.over_sampling import SMOTE
from tensorflow.python.keras.layers.pooling import GlobalPooling1D

columns = (['duration'
    , 'protocol_type'
    , 'service'
    , 'flag'
    , 'src_bytes'
    , 'dst_bytes'
    , 'land'
    , 'wrong_fragment'
    , 'urgent'
    , 'hot'
    , 'num_failed_logins'
    , 'logged_in'
    , 'num_compromised'
    , 'root_shell'
    , 'su_attempted'
    , 'num_root'
    , 'num_file_creations'
    , 'num_shells'
    , 'num_access_files'
    , 'num_outbound_cmds'
    , 'is_host_login'
    , 'is_guest_login'
    , 'count'
    , 'srv_count'
    , 'serror_rate'
    , 'srv_serror_rate'
    , 'rerror_rate'
    , 'srv_rerror_rate'
    , 'same_srv_rate'
    , 'diff_srv_rate'
    , 'srv_diff_host_rate'
    , 'dst_host_count'
    , 'dst_host_srv_count'
    , 'dst_host_same_srv_rate'
    , 'dst_host_diff_srv_rate'
    , 'dst_host_same_src_port_rate'
    , 'dst_host_srv_diff_host_rate'
    , 'dst_host_serror_rate'
    , 'dst_host_srv_serror_rate'
    , 'dst_host_rerror_rate'
    , 'dst_host_srv_rerror_rate'
    , 'attack'
    , 'level'])

# 加载数据集
data_train = pd.read_csv('KDDTrain+.csv', header=None, names=columns)
data_test = pd.read_csv('KDDTest+.csv', header=None, names=columns)

attack_n = []
for i in data_train['attack']:
    if i == 'normal':
        attack_n.append(0)
    else:
        attack_n.append(1)

data_train['attack'] = attack_n

attack_n = []
for i in data_test['attack']:
    if i == 'normal':
        attack_n.append(0)
    else:
        attack_n.append(1)

data_test['attack'] = attack_n

# 对数据中的标签进行数据数值化
clm = ['protocol_type', 'service', 'flag']

# 创建LabelEncoder实例
label_encoder = LabelEncoder()

for x in clm:  # 遍历列名标签
    data_train[x] = label_encoder.fit_transform(data_train[x])  # 对训练数据集的指定列进行标签编码
    data_test[x] = label_encoder.fit_transform(data_test[x])  # 对测试数据集的指定列进行标签编码

y = data_train['attack'].copy()
x = data_train.drop('attack', axis=1)

# 数据x
x_train = data_train.drop('attack', axis=1)
x_test = data_test.drop('attack', axis=1)

# 标签y
y_train = data_train['attack'].copy()  # 训练集
y_test = data_test['attack'].copy()  # 测试集


# 数据标准化
scaler = StandardScaler()
x_train_scaled = scaler.fit_transform(x_train)
x_test_scaled = scaler.transform(x_test)

# 将标准化后的数据重塑为CNN所需的格式 (samples, time_steps, features)
x_train_scaled = np.expand_dims(x_train_scaled, axis=2)
x_test_scaled = np.expand_dims(x_test_scaled, axis=2)


# 构建卷积神经网络模型
model = Sequential()
model.add(Conv1D(filters=64, kernel_size=3, activation='relu',
                 input_shape=(x_train_scaled.shape[1], x_train_scaled.shape[2])))

# 一维最大池化层
model.add(MaxPooling1D(pool_size=5, strides=2, padding='same'))
# 添加批量归一化层
model.add(BatchNormalization())

model.add(SeqSelfAttention())
model.add(Dropout(0.5))  # 在第二层双向GRU后添加Dropout

# 添加BiGRU层
# 添加第一层双向GRU
model.add(Bidirectional(GRU(units=64, return_sequences=True)))

model.add(MaxPooling1D(pool_size=5, strides=2, padding='same'))
# 添加批量归一化层
model.add(BatchNormalization())

model.add(SeqSelfAttention())
model.add(Dropout(0.5))

# 添加全局平均池化层，放在末尾
model.add(GlobalAveragePooling1D())  # 将时间步长缩减为1，输出每个特征的平均值

# 添加分类层
model.add(Dense(1, activation='sigmoid'))

# 编译模型
model.compile(optimizer=Adam(), loss='binary_crossentropy', metrics=['accuracy'])

# 训练模型
model.fit(x_train_scaled, y_train, epochs=5, batch_size=64)


# 使用模型进行预测
y_pred_proba = model.predict(x_test_scaled)
y_pred = (y_pred_proba >= 0.5).astype(int)

# 计算混淆矩阵
cm = confusion_matrix(y_test, y_pred)

# 从混淆矩阵中提取TP, FP, TN, FN
TP = cm[1, 1]
FP = cm[0, 1]
TN = cm[0, 0]
FN = cm[1, 0]

# 计算误报率 (FPR)
FPR = FP / (FP + TN)
# 计算准确率
accuracy = accuracy_score(y_test, y_pred)
# 计算精确度 (Accuracy)
precision = precision_score(y_test, y_pred)
# 计算F1-score
f1 = f1_score(y_test, y_pred)
# 计算召回率
recall = recall_score(y_test, y_pred)

print(f"Accuracy: {accuracy}")
print(f'F1-score: {f1}')
print(f"Recall: {recall}")

