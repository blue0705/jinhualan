import numpy as np
import pandas as pd
from keras.models import Sequential
from keras.layers import Dense
from keras.src.layers import Dropout, LSTM
from sklearn.metrics import recall_score, confusion_matrix, accuracy_score, precision_score, f1_score
from sklearn.preprocessing import LabelEncoder, StandardScaler

columns = (['duration'
    , 'protocol_type'
    , 'service'
    , 'flag'
    , 'src_bytes'
    , 'dst_bytes'
    , 'land'
    , 'wrong_fragment'
    , 'urgent'
    , 'hot'
    , 'num_failed_logins'
    , 'logged_in'
    , 'num_compromised'
    , 'root_shell'
    , 'su_attempted'
    , 'num_root'
    , 'num_file_creations'
    , 'num_shells'
    , 'num_access_files'
    , 'num_outbound_cmds'
    , 'is_host_login'
    , 'is_guest_login'
    , 'count'
    , 'srv_count'
    , 'serror_rate'
    , 'srv_serror_rate'
    , 'rerror_rate'
    , 'srv_rerror_rate'
    , 'same_srv_rate'
    , 'diff_srv_rate'
    , 'srv_diff_host_rate'
    , 'dst_host_count'
    , 'dst_host_srv_count'
    , 'dst_host_same_srv_rate'
    , 'dst_host_diff_srv_rate'
    , 'dst_host_same_src_port_rate'
    , 'dst_host_srv_diff_host_rate'
    , 'dst_host_serror_rate'
    , 'dst_host_srv_serror_rate'
    , 'dst_host_rerror_rate'
    , 'dst_host_srv_rerror_rate'
    , 'attack'
    , 'level'])

# 加载数据集
data_train = pd.read_csv('KDDTrain+.csv', header=None, names=columns)
data_test = pd.read_csv('KDDTest+.csv', header=None, names=columns)

attack_n = []
for i in data_train['attack']:
    if i == 'normal':
        attack_n.append(0)
    else:
        attack_n.append(1)

data_train['attack'] = attack_n

attack_n = []
for i in data_test['attack']:
    if i == 'normal':
        attack_n.append(0)
    else:
        attack_n.append(1)

data_test['attack'] = attack_n

# 对数据中的标签进行独热编码
# 选择需要进行独热编码的列名
clm = ['protocol_type', 'service', 'flag']

# 创建OneHotEncoder实例
onehot_encoder = LabelEncoder()

for x in clm:  # 遍历列名标签
    data_train[x] = onehot_encoder.fit_transform(data_train[x])  # 对训练数据集的指定列进行标签编码
    data_test[x] = onehot_encoder.fit_transform(data_test[x])  # 对测试数据集的指定列进行标签编码

y = data_train['attack'].copy()
x = data_train.drop('attack', axis=1)

# 数据x
x_train = data_train.drop('attack', axis=1)
x_test = data_test.drop('attack', axis=1)

# 标签y
y_train = data_train['attack'].copy()  # 训练集
y_test = data_test['attack'].copy()  # 测试集

# 数据标准化
scaler = StandardScaler()
x_train_scaled = scaler.fit_transform(x_train)
x_test_scaled = scaler.transform(x_test)

# 将标准化后的数据重塑为CNN所需的格式 (samples, time_steps, features)
x_train_scaled = np.expand_dims(x_train_scaled, axis=2)
x_test_scaled = np.expand_dims(x_test_scaled, axis=2)


model = Sequential([
    LSTM(64, activation='relu', input_shape=(x_train_scaled.shape[1], x_train_scaled.shape[2])),  # 第一个LSTM层
    Dropout(0.5),  # 添加Dropout以减少过拟合
    Dense(128, activation='relu'),  # 全连接层
    Dense(1, activation='sigmoid')  # 输出层，用于二分类（正常/恶意）
])

# 编译模型
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

# 训练模型
model.fit(x_train_scaled, y_train, epochs=5, batch_size=64)

# 使用模型进行预测
y_pred_proba = model.predict(x_test_scaled)
y_pred = (y_pred_proba >= 0.5).astype(int)

# 计算混淆矩阵
cm = confusion_matrix(y_test, y_pred)

# 从混淆矩阵中提取TP, FP, TN, FN
TP = cm[1, 1]
FP = cm[0, 1]
TN = cm[0, 0]
FN = cm[1, 0]

# 计算误报率 (FPR)
FPR = FP / (FP + TN)
# 计算准确率
accuracy = accuracy_score(y_test, y_pred)
# 计算精确度 (Accuracy)
precision = precision_score(y_test, y_pred)
# 计算F1-score
f1 = f1_score(y_test, y_pred)
# 计算召回率
recall = recall_score(y_test, y_pred)

print(f"Accuracy: {accuracy}")
print(f'F1-score: {f1}')
print(f"Recall: {recall}")
